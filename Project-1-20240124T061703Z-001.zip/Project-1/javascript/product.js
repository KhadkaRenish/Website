function message(){
    alert("The product is added to your cart");
}
function info(){
    alert("Thankyou for purchsing");
}